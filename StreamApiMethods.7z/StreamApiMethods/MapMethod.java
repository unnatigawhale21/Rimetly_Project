import java.util.Arrays;
import java.util.List;

public class MapMethod {
    
    public static void main(String[] args) {

        List<Integer>list = Arrays.asList(3, 4, 5, 6, 10);

        System.out.println("The stream is:");

        list.stream().map(number -> number*5).forEach(System.out::println);

       
    }
}
 