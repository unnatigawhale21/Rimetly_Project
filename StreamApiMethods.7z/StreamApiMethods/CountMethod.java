import java.util.Arrays;
import java.util.List;

public class CountMethod {
    
    public static void main(String[] args) {

        List<Integer> list  =  Arrays.asList(22, 24, 1, 20, 5, 98, 100);

        long total = list.stream().count();

        System.out.println(total);
    }
}
