import java.util.*;

class FilterMethod{
    
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(3, 6, 7, 8, 9, 10);

        list.stream()
            .filter(num -> num %  2 == 0)
            .forEach(System.out::println);
    }
}