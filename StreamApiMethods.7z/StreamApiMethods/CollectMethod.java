import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CollectMethod {

    public static void main(String[] args) {

        List<String> listOfString = Arrays.asList("Java", "C", "C++", "JavaScript");

        System.out.println("Input list of string:" + listOfString);

        List<String> listOfStringStartWithJ = listOfString.stream()
                                                            .filter(s -> s.startsWith("J"))
                                                            .collect(Collectors.toList());

        System.out.println("list of string start with J:" + listOfStringStartWithJ);
    }
    
}
