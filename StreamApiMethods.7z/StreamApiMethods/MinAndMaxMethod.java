import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class MinAndMaxMethod {

    // public static void main(String[] args) {

    //     List<Integer> list = Arrays.asList(12, 15, -12, 8, 10);

    //     Integer var = list.stream().min(Integer::compare).get();

    //     System.out.println(var);

    // }
    
//Max method
    public static void main(String[] args) {

        List<Integer> list = Arrays.asList(12, 15, -12, 8, 10);

        Optional<Integer> var = list.stream() 
                    .min(Comparator.reverseOrder()); 

                    if(var.isPresent()){ 
                        System.out.println(var.get()); 
                        } 
                        else{ 
                            System.out.println("NULL"); 
                        } 


    }


}