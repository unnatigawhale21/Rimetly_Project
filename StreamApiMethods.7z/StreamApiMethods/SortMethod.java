import java.util.Arrays;
import java.util.List;

public class SortMethod {
    
    public static void main(String[] args){

        List<Integer> list = Arrays.asList(7, 12, 20, 5, 18, 0);
        System.out.println("the sorted list is: ");
        list.stream().sorted().forEach(System.out::println);
    }
}
